//
//  QuestionInfo+CoreDataClass.swift
//  Trivia App
//
//  Created by chitranjan singh on 14/10/20.
//  Copyright © 2020 chitranjan singh. All rights reserved.
//
//

import Foundation
import CoreData

@objc(QuestionInfo)
public class QuestionInfo: NSManagedObject {

}
